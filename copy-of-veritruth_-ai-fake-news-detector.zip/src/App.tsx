import React, { useState } from 'react';
import { 
  Search, 
  AlertTriangle, 
  CheckCircle2, 
  Info, 
  ShieldAlert, 
  ShieldCheck, 
  ExternalLink,
  Loader2,
  History,
  Newspaper,
  ArrowRight,
  Fingerprint
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { analyzeNews, type AnalysisResult } from './services/geminiService';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function App() {
  const [inputText, setInputText] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleAnalyze = async () => {
    if (!inputText.trim()) return;
    
    setIsAnalyzing(true);
    setError(null);
    try {
      const data = await analyzeNews(inputText);
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unexpected error occurred');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getVerdictColor = (verdict: string) => {
    switch (verdict) {
      case 'REAL': return 'text-emerald-500 border-emerald-500/20 bg-emerald-500/5';
      case 'FAKE': return 'text-rose-500 border-rose-500/20 bg-rose-500/5';
      case 'MISLEADING': return 'text-amber-500 border-amber-500/20 bg-amber-500/5';
      default: return 'text-zinc-500 border-zinc-500/20 bg-zinc-500/5';
    }
  };

  const getVerdictIcon = (verdict: string) => {
    switch (verdict) {
      case 'REAL': return <ShieldCheck className="w-8 h-8" />;
      case 'FAKE': return <ShieldAlert className="w-8 h-8" />;
      case 'MISLEADING': return <AlertTriangle className="w-8 h-8" />;
      default: return <Info className="w-8 h-8" />;
    }
  };

  return (
    <div className="min-h-screen bg-[#E4E3E0] text-[#141414] font-sans selection:bg-[#141414] selection:text-[#E4E3E0]">
      {/* Header */}
      <header className="border-b border-[#141414] p-6 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <Fingerprint className="w-8 h-8" />
          <h1 className="text-xl font-bold tracking-tighter uppercase italic font-serif">VeriTruth System v1.0</h1>
        </div>
        <div className="flex items-center gap-6 text-[11px] uppercase tracking-widest opacity-50 font-mono">
          <span>Status: Operational</span>
          <span>Lat: 37.7749° N</span>
          <span>Lon: 122.4194° W</span>
        </div>
      </header>

      <main className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 min-h-[calc(100vh-89px)]">
        {/* Input Section */}
        <section className="lg:col-span-5 border-r border-[#141414] p-8 flex flex-col gap-8">
          <div className="space-y-2">
            <span className="text-[11px] uppercase tracking-widest opacity-50 font-mono">01 / Input Analysis</span>
            <h2 className="text-4xl font-serif italic leading-tight">Feed the system.</h2>
            <p className="text-sm opacity-70 max-w-md">
              Paste news articles, headlines, or social media claims. Our neural engine cross-references data against real-time global indices.
            </p>
          </div>

          <div className="flex-1 flex flex-col gap-4">
            <div className="relative flex-1">
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Paste news content here..."
                className="w-full h-full bg-white/50 border border-[#141414] p-6 rounded-none focus:outline-none focus:ring-1 focus:ring-[#141414] resize-none font-mono text-sm placeholder:opacity-30"
              />
              <div className="absolute bottom-4 right-4 text-[10px] font-mono opacity-30">
                CHARS: {inputText.length}
              </div>
            </div>

            <button
              onClick={handleAnalyze}
              disabled={isAnalyzing || !inputText.trim()}
              className={cn(
                "group relative w-full py-6 border border-[#141414] uppercase tracking-[0.2em] text-sm font-bold transition-all overflow-hidden",
                isAnalyzing ? "bg-zinc-200 cursor-not-allowed" : "hover:bg-[#141414] hover:text-[#E4E3E0]"
              )}
            >
              <span className="relative z-10 flex items-center justify-center gap-3">
                {isAnalyzing ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Processing Neural Batch...
                  </>
                ) : (
                  <>
                    Initiate Detection
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </>
                )}
              </span>
            </button>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 border border-[#141414]/10 bg-white/20">
              <History className="w-4 h-4 mb-2 opacity-50" />
              <span className="block text-[10px] uppercase tracking-wider opacity-50 mb-1">Recent Scans</span>
              <span className="text-xs font-mono">4,291 Global</span>
            </div>
            <div className="p-4 border border-[#141414]/10 bg-white/20">
              <Newspaper className="w-4 h-4 mb-2 opacity-50" />
              <span className="block text-[10px] uppercase tracking-wider opacity-50 mb-1">Source Index</span>
              <span className="text-xs font-mono">82.1M Verified</span>
            </div>
          </div>
        </section>

        {/* Results Section */}
        <section className="lg:col-span-7 p-8 bg-[#DCDAD7] relative overflow-y-auto max-h-[calc(100vh-89px)]">
          <AnimatePresence mode="wait">
            {!result && !isAnalyzing && !error && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="h-full flex flex-col items-center justify-center text-center space-y-6 opacity-20"
              >
                <Search className="w-24 h-24 stroke-[1px]" />
                <div className="space-y-2">
                  <p className="text-xl font-serif italic">System Idle</p>
                  <p className="text-xs font-mono uppercase tracking-widest">Awaiting input for verification</p>
                </div>
              </motion.div>
            )}

            {isAnalyzing && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="h-full flex flex-col items-center justify-center space-y-8"
              >
                <div className="relative">
                  <div className="w-32 h-32 border border-[#141414] animate-spin [animation-duration:3s]" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-16 h-16 border border-[#141414] animate-spin [animation-duration:1.5s] [animation-direction:reverse]" />
                  </div>
                </div>
                <div className="text-center space-y-2">
                  <p className="text-xl font-serif italic">Analyzing Metadata...</p>
                  <div className="flex gap-1 justify-center">
                    {[0, 1, 2].map(i => (
                      <motion.div
                        key={i}
                        animate={{ opacity: [0.2, 1, 0.2] }}
                        transition={{ duration: 1, repeat: Infinity, delay: i * 0.2 }}
                        className="w-1 h-1 bg-[#141414]"
                      />
                    ))}
                  </div>
                </div>
              </motion.div>
            )}

            {error && (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="h-full flex flex-col items-center justify-center text-center space-y-4"
              >
                <AlertTriangle className="w-16 h-16 text-rose-500" />
                <div className="space-y-2">
                  <p className="text-xl font-serif italic text-rose-500">System Error</p>
                  <p className="text-sm font-mono max-w-xs">{error}</p>
                </div>
                <button 
                  onClick={() => setError(null)}
                  className="px-6 py-2 border border-[#141414] text-xs uppercase tracking-widest hover:bg-[#141414] hover:text-[#E4E3E0] transition-colors"
                >
                  Reset System
                </button>
              </motion.div>
            )}

            {result && !isAnalyzing && (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-12 pb-12"
              >
                {/* Verdict Card */}
                <div className={cn(
                  "p-10 border-2 flex flex-col md:flex-row items-start md:items-center gap-10 transition-all shadow-[8px_8px_0px_0px_rgba(20,20,20,1)]",
                  getVerdictColor(result.verdict)
                )}>
                  <div className="p-6 border-2 border-current rounded-none bg-white/10">
                    {getVerdictIcon(result.verdict)}
                  </div>
                  <div className="flex-1 space-y-2">
                    <div className="flex items-center gap-4">
                      <span className="text-[11px] uppercase tracking-[0.2em] font-bold opacity-70 font-mono">Neural Verdict</span>
                      <div className="h-[1px] flex-1 bg-current opacity-20" />
                      <span className="px-3 py-1 border border-current text-[10px] font-bold font-mono">CONFIDENCE: {result.confidence}%</span>
                    </div>
                    <h3 className="text-7xl font-serif italic leading-none uppercase tracking-tighter">{result.verdict}</h3>
                  </div>
                </div>

                {/* Visual Evidence & Summary */}
                <div className="grid grid-cols-1 xl:grid-cols-12 gap-10">
                  <div className="xl:col-span-7 space-y-6">
                    <div className="space-y-4">
                      <div className="flex items-center gap-3">
                        <span className="text-[11px] uppercase tracking-widest font-mono font-bold">02 / Visual Context</span>
                        <div className="h-[1px] flex-1 bg-[#141414]/10" />
                      </div>
                      {result.imageUrl ? (
                        <div className="relative aspect-video border border-[#141414] overflow-hidden group">
                          <img 
                            src={result.imageUrl} 
                            alt="Visual Context" 
                            className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700"
                            referrerPolicy="no-referrer"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-[#141414]/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity p-6 flex items-end">
                            <p className="text-[10px] text-white font-mono uppercase tracking-widest">AI Generated Illustrative Context</p>
                          </div>
                        </div>
                      ) : (
                        <div className="aspect-video border border-[#141414]/10 bg-white/20 flex items-center justify-center">
                          <p className="text-[10px] font-mono opacity-30 uppercase tracking-widest">Visual generation skipped</p>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="xl:col-span-5 space-y-8">
                    <div className="space-y-4">
                      <h4 className="text-[11px] uppercase tracking-widest font-mono font-bold border-b border-[#141414] pb-2">Executive Summary</h4>
                      <p className="text-sm leading-relaxed font-medium">{result.summary}</p>
                    </div>
                    <div className="space-y-4">
                      <h4 className="text-[11px] uppercase tracking-widest font-mono font-bold border-b border-[#141414] pb-2">Bias Assessment</h4>
                      <div className="p-4 bg-white/40 border-l-4 border-[#141414]">
                        <p className="text-sm leading-relaxed italic">"{result.biasAnalysis}"</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Knowledge Deep Dive */}
                <div className="p-8 border border-[#141414] bg-[#141414] text-[#E4E3E0] space-y-6">
                  <div className="flex items-center justify-between">
                    <h4 className="text-[11px] uppercase tracking-[0.3em] font-bold font-mono">03 / Knowledge Deep Dive</h4>
                    <Info className="w-4 h-4 opacity-50" />
                  </div>
                  <div className="space-y-4">
                    <p className="text-lg font-serif italic leading-relaxed opacity-90">
                      {result.deepDive}
                    </p>
                  </div>
                </div>

                {/* Verification Grid */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
                  {/* Red Flags */}
                  <div className="space-y-6">
                    <div className="flex items-center gap-3">
                      <span className="text-[11px] uppercase tracking-widest font-mono font-bold">04 / Neural Red Flags</span>
                      <div className="h-[1px] flex-1 bg-[#141414]/10" />
                    </div>
                    <div className="space-y-3">
                      {result.redFlags.map((flag, i) => (
                        <div key={i} className="flex items-start gap-4 p-4 bg-white/50 border border-[#141414]/10 group hover:border-[#141414] transition-colors">
                          <div className="w-6 h-6 flex items-center justify-center border border-[#141414]/20 text-[10px] font-mono">
                            {String(i + 1).padStart(2, '0')}
                          </div>
                          <span className="text-xs font-medium">{flag}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Factual Checks */}
                  <div className="space-y-6">
                    <div className="flex items-center gap-3">
                      <span className="text-[11px] uppercase tracking-widest font-mono font-bold">05 / Grounding Verification</span>
                      <div className="h-[1px] flex-1 bg-[#141414]/10" />
                    </div>
                    <div className="space-y-4">
                      {result.factualCheck.map((check, i) => (
                        <div key={i} className="p-5 bg-white border border-[#141414] space-y-3 shadow-[4px_4px_0px_0px_rgba(20,20,20,0.1)]">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className={cn(
                                "w-2 h-2 rounded-full",
                                check.status === 'CORRECT' ? "bg-emerald-500" : 
                                check.status === 'INCORRECT' ? "bg-rose-500" : "bg-amber-500"
                              )} />
                              <span className={cn(
                                "text-[10px] font-mono font-bold uppercase tracking-widest",
                                check.status === 'CORRECT' ? "text-emerald-600" : 
                                check.status === 'INCORRECT' ? "text-rose-600" : "text-amber-600"
                              )}>
                                {check.status}
                              </span>
                            </div>
                            {check.source && (
                              <a 
                                href={check.source} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="text-[10px] font-mono uppercase tracking-widest flex items-center gap-2 hover:bg-[#141414] hover:text-white px-2 py-1 border border-[#141414] transition-all"
                              >
                                View Source <ExternalLink className="w-3 h-3" />
                              </a>
                            )}
                          </div>
                          <p className="text-sm font-serif italic leading-snug">"{check.claim}"</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="pt-8 border-t border-[#141414]/10">
                  <button 
                    onClick={() => {
                      setResult(null);
                      setInputText('');
                    }}
                    className="w-full py-6 bg-[#141414] text-[#E4E3E0] text-xs uppercase tracking-[0.5em] font-bold hover:bg-zinc-800 transition-all flex items-center justify-center gap-4"
                  >
                    <Fingerprint className="w-4 h-4" />
                    Reset Neural Session
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </section>
      </main>

      {/* Footer Info */}
      <footer className="border-t border-[#141414] p-4 flex justify-between items-center bg-white/10">
        <div className="text-[9px] font-mono uppercase tracking-widest opacity-40">
          © 2026 VeriTruth Neural Systems • All Rights Reserved
        </div>
        <div className="flex gap-4">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-[9px] font-mono uppercase tracking-widest opacity-40">Neural Engine: Active</span>
        </div>
      </footer>
    </div>
  );
}
